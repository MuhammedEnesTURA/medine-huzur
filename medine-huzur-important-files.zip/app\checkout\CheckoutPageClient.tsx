"use client";

import Link from "next/link";
import { useMemo, useState } from "react";
import {
  ArrowLeft,
  CheckCircle2,
  Gift,
  Loader2,
  PackageCheck,
  ShieldCheck,
  ShoppingBag,
  Truck,
} from "lucide-react";
import { apiUrl } from "../../lib/api";
import { useAuth } from "../../context/AuthContext";
import { CartItem, useCart } from "../../context/CartContext";

const MIN_CART_TOTAL = 250;

type CheckoutForm = {
  fullName: string;
  email: string;
  phone: string;
  city: string;
  district: string;
  addressLine: string;
  postalCode: string;
  orderNote: string;
};

type SubmitState =
  | {
      type: "success";
      message: string;
      orderNumber?: string | null;
    }
  | {
      type: "error";
      message: string;
    }
  | null;

function formatPrice(value: number) {
  return new Intl.NumberFormat("tr-TR", {
    style: "currency",
    currency: "TRY",
    maximumFractionDigits: 2,
  }).format(value);
}

function formatAttributes(attrs: CartItem["selectedAttributes"]) {
  if (!attrs) return null;

  const entries = Object.entries(attrs);
  if (entries.length === 0) return null;

  return entries.map(([key, value]) => `${key}: ${value}`).join(" • ");
}

function toOrderItem(item: CartItem, isGiftPackageItem: boolean) {
  return {
    productId: item.productId,
    variantId: item.variantId,
    sku: item.sku,
    productName: item.name,
    unitPrice: item.unitPrice,
    quantity: item.quantity,
    selectedAttributes: item.selectedAttributes,
    isGiftPackageItem,
  };
}

function CheckoutLine({
  item,
  badge,
}: {
  item: CartItem;
  badge?: string;
}) {
  const attrs = formatAttributes(item.selectedAttributes);

  return (
    <div className="flex gap-3 rounded-2xl border border-border-soft bg-panel/65 p-3">
      <Link
        href={`/product/${item.slug}`}
        className="relative flex h-16 w-16 shrink-0 items-center justify-center overflow-hidden rounded-xl border border-border-soft bg-panel-3"
      >
        {item.imageUrl ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img
            src={item.imageUrl}
            alt={item.name}
            className="h-full w-full object-contain p-1.5"
          />
        ) : (
          <ShoppingBag className="h-6 w-6 text-mhgreen" />
        )}
      </Link>

      <div className="min-w-0 flex-1">
        <div className="flex flex-wrap items-start justify-between gap-2">
          <div className="min-w-0">
            <Link
              href={`/product/${item.slug}`}
              className="line-clamp-2 text-sm font-black text-foreground transition hover:text-mhgreen"
            >
              {item.name}
            </Link>

            <p className="mt-1 text-xs font-semibold text-muted">
              {item.quantity} adet · {item.sku}
            </p>

            {attrs && (
              <p className="mt-1 text-xs font-semibold text-muted">{attrs}</p>
            )}
          </div>

          {badge && (
            <span className="rounded-full border border-mhgreen/25 bg-mhgreen/10 px-2 py-1 text-[10px] font-black text-mhgreen">
              {badge}
            </span>
          )}
        </div>

        <p className="mt-2 text-sm font-black text-mhgreen">
          {formatPrice(item.unitPrice * item.quantity)}
        </p>
      </div>
    </div>
  );
}

export default function CheckoutPageClient() {
  const { user, token, isAuthenticated } = useAuth();
  const { items, giftPackage, subtotal, giftSubtotal, total, clearCart } =
    useCart();

  const [form, setForm] = useState<CheckoutForm>({
    fullName: "",
    email: user?.email ?? "",
    phone: "",
    city: "",
    district: "",
    addressLine: "",
    postalCode: "",
    orderNote: "",
  });

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitState, setSubmitState] = useState<SubmitState>(null);

  const allItems = useMemo(
    () => [
      ...items.map((item) => toOrderItem(item, false)),
      ...giftPackage.items.map((item) => toOrderItem(item, true)),
    ],
    [items, giftPackage.items]
  );

  const isEmpty = items.length === 0 && giftPackage.items.length === 0;
  const missingAmount = Math.max(0, MIN_CART_TOTAL - total);
  const canSubmit =
    !isEmpty &&
    total >= MIN_CART_TOTAL &&
    form.fullName.trim().length >= 2 &&
    form.email.trim().length >= 5 &&
    form.phone.trim().length >= 8 &&
    form.city.trim().length >= 2 &&
    form.district.trim().length >= 2 &&
    form.addressLine.trim().length >= 10;

  const updateForm = (key: keyof CheckoutForm, value: string) => {
    setForm((current) => ({
      ...current,
      [key]: value,
    }));
    setSubmitState(null);
  };

  const handleSubmit = async () => {
    if (!canSubmit || isSubmitting) return;

    setIsSubmitting(true);
    setSubmitState(null);

    const normalItems = items.map((item) => ({
  productId: item.productId,
  variantId: item.variantId,
  sku: item.sku,
  name: item.name,
  unitPrice: item.unitPrice,
  quantity: item.quantity,
  selectedAttributes: item.selectedAttributes,
}));

const giftItems = giftPackage.items.map((item) => ({
  productId: item.productId,
  variantId: item.variantId,
  sku: item.sku,
  name: item.name,
  unitPrice: item.unitPrice,
  quantity: item.quantity,
  selectedAttributes: item.selectedAttributes,
}));

const addressText = [
  form.addressLine.trim(),
  form.district.trim(),
  form.city.trim(),
  form.postalCode.trim(),
]
  .filter(Boolean)
  .join(" / ");

const payload = {
  customerName: form.fullName.trim(),
  email: form.email.trim(),
  phone: form.phone.trim(),
  address: addressText,
  paymentMethod: "Kart (Sanal POS) - yakında",
  items: normalItems,
  giftPackage:
    giftPackage.enabled && giftItems.length > 0
      ? {
          enabled: true,
          quantity: 1,
          note: giftPackage.note.trim() || giftPackage.title.trim() || null,
          sampleImageUrl: null,
          items: giftItems,
        }
      : null,
  legalConsents: {
    preInformationAccepted: true,
    distanceSalesAccepted: true,
    acceptedAtUtc: new Date().toISOString(),
  },
};

    try {
      const res = await fetch(apiUrl("/api/orders/checkout"), {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          ...(token ? { Authorization: `Bearer ${token}` } : {}),
        },
        body: JSON.stringify(payload),
      });

      const data = await res.json().catch(() => null);

      if (!res.ok) {
        setSubmitState({
          type: "error",
          message:
            data?.message ||
            data?.title ||
            "Sipariş oluşturulamadı. Bilgileri kontrol edip tekrar deneyin.",
        });
        return;
      }

      clearCart();

      setSubmitState({
        type: "success",
        message: "Sipariş başarıyla oluşturuldu.",
        orderNumber: data?.orderNumber ?? data?.order?.orderNumber ?? null,
      });
    } catch {
      setSubmitState({
        type: "error",
        message:
          "Sunucuya ulaşılamadı. Backend çalışıyor mu kontrol edip tekrar deneyin.",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  if (isEmpty && submitState?.type !== "success") {
    return (
      <main className="page-shell">
        <section className="page-container py-5 md:py-6">
          <div className="rounded-[1.35rem] border border-border-soft bg-panel/72 p-8 text-center shadow-[0_18px_50px_rgba(0,0,0,0.18)]">
            <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-3xl border border-border-soft bg-panel-3">
              <ShoppingBag className="h-8 w-8 text-mhgreen" />
            </div>

            <h1 className="mt-5 text-2xl font-black text-foreground">
              Checkout için sepet boş
            </h1>

            <p className="mx-auto mt-2 max-w-md text-sm leading-6 text-muted">
              Sipariş oluşturmak için önce ürün eklemelisin.
            </p>

            <Link href="/products" className="btn-premium mt-5 min-h-10 text-sm">
              Ürünlere Dön
            </Link>
          </div>
        </section>
      </main>
    );
  }

  return (
    <main className="page-shell">
      <section className="page-container py-5 md:py-6">
        <Link
          href="/cart"
          className="inline-flex min-h-9 items-center gap-2 rounded-xl border border-border-soft bg-panel/70 px-3 text-sm font-bold text-muted transition hover:text-foreground"
        >
          <ArrowLeft className="h-4 w-4" />
          Sepete dön
        </Link>

        <div className="mt-5 grid gap-5 lg:grid-cols-[1fr_390px]">
          <div className="space-y-5">
            <section className="rounded-[1.35rem] border border-border-soft bg-panel/72 p-4 shadow-[0_18px_50px_rgba(0,0,0,0.18)] md:p-5">
              <p className="text-xs font-black uppercase tracking-[0.14em] text-mhgreen">
                Checkout
              </p>

              <h1 className="mt-2 text-2xl font-black tracking-[-0.03em] text-foreground md:text-3xl">
                Sipariş bilgileri
              </h1>

              <p className="mt-2 max-w-2xl text-sm leading-6 text-muted">
                Teslimat ve iletişim bilgilerini doldur. Sipariş oluşturulduktan
                sonra ödeme/kargo adımlarına geçeceğiz.
              </p>

              {submitState && (
                <div
                  className={`mt-4 rounded-2xl border p-4 ${
                    submitState.type === "success"
                      ? "border-mhgreen/30 bg-mhgreen/10"
                      : "border-danger/30 bg-danger/10"
                  }`}
                >
                  <div className="flex gap-3">
                    <CheckCircle2
                      className={`mt-0.5 h-5 w-5 shrink-0 ${
                        submitState.type === "success"
                          ? "text-mhgreen"
                          : "text-danger"
                      }`}
                    />
                    <div>
                      <p
                        className={`text-sm font-black ${
                          submitState.type === "success"
                            ? "text-mhgreen"
                            : "text-danger"
                        }`}
                      >
                        {submitState.message}
                      </p>

                      {submitState.type === "success" &&
                        submitState.orderNumber && (
                          <p className="mt-1 text-sm font-bold text-foreground">
                            Sipariş No: {submitState.orderNumber}
                          </p>
                        )}

                      {submitState.type === "success" && (
                        <Link
                          href={
                            submitState.orderNumber
                              ? `/guest-orders?orderNumber=${submitState.orderNumber}`
                              : "/guest-orders"
                          }
                          className="mt-3 inline-flex min-h-9 items-center justify-center rounded-xl bg-mhgreen px-4 text-sm font-black text-white transition hover:bg-mhgreen-dark"
                        >
                          Siparişi Sorgula
                        </Link>
                      )}
                    </div>
                  </div>
                </div>
              )}
            </section>

            <section className="rounded-[1.35rem] border border-border-soft bg-panel/72 p-4 shadow-[0_18px_50px_rgba(0,0,0,0.18)] md:p-5">
              <h2 className="text-xl font-black text-foreground">
                Müşteri bilgileri
              </h2>

              <div className="mt-4 grid gap-3 md:grid-cols-2">
                <label>
                  <span className="text-xs font-black uppercase tracking-[0.12em] text-muted-2">
                    Ad soyad
                  </span>
                  <input
                    value={form.fullName}
                    onChange={(event) =>
                      updateForm("fullName", event.target.value)
                    }
                    className="input-premium mt-2 min-h-10 text-sm"
                    placeholder="Ad Soyad"
                  />
                </label>

                <label>
                  <span className="text-xs font-black uppercase tracking-[0.12em] text-muted-2">
                    Telefon
                  </span>
                  <input
                    value={form.phone}
                    onChange={(event) => updateForm("phone", event.target.value)}
                    className="input-premium mt-2 min-h-10 text-sm"
                    placeholder="05xx xxx xx xx"
                  />
                </label>

                <label className="md:col-span-2">
                  <span className="text-xs font-black uppercase tracking-[0.12em] text-muted-2">
                    E-posta
                  </span>
                  <input
                    value={form.email}
                    onChange={(event) => updateForm("email", event.target.value)}
                    className="input-premium mt-2 min-h-10 text-sm"
                    placeholder="ornek@mail.com"
                    type="email"
                  />
                </label>
              </div>
            </section>

            <section className="rounded-[1.35rem] border border-border-soft bg-panel/72 p-4 shadow-[0_18px_50px_rgba(0,0,0,0.18)] md:p-5">
              <h2 className="text-xl font-black text-foreground">
                Teslimat adresi
              </h2>

              <div className="mt-4 grid gap-3 md:grid-cols-2">
                <label>
                  <span className="text-xs font-black uppercase tracking-[0.12em] text-muted-2">
                    İl
                  </span>
                  <input
                    value={form.city}
                    onChange={(event) => updateForm("city", event.target.value)}
                    className="input-premium mt-2 min-h-10 text-sm"
                    placeholder="İstanbul"
                  />
                </label>

                <label>
                  <span className="text-xs font-black uppercase tracking-[0.12em] text-muted-2">
                    İlçe
                  </span>
                  <input
                    value={form.district}
                    onChange={(event) =>
                      updateForm("district", event.target.value)
                    }
                    className="input-premium mt-2 min-h-10 text-sm"
                    placeholder="Üsküdar"
                  />
                </label>

                <label>
                  <span className="text-xs font-black uppercase tracking-[0.12em] text-muted-2">
                    Posta kodu
                  </span>
                  <input
                    value={form.postalCode}
                    onChange={(event) =>
                      updateForm("postalCode", event.target.value)
                    }
                    className="input-premium mt-2 min-h-10 text-sm"
                    placeholder="Opsiyonel"
                  />
                </label>

                <label className="md:col-span-2">
                  <span className="text-xs font-black uppercase tracking-[0.12em] text-muted-2">
                    Açık adres
                  </span>
                  <textarea
                    value={form.addressLine}
                    onChange={(event) =>
                      updateForm("addressLine", event.target.value)
                    }
                    className="input-premium mt-2 min-h-24 resize-none py-3 text-sm"
                    placeholder="Mahalle, cadde, sokak, bina, daire..."
                  />
                </label>
              </div>
            </section>

            {giftPackage.enabled && giftPackage.items.length > 0 && (
              <section className="rounded-[1.35rem] border border-mhgreen/25 bg-mhgreen/10 p-4 md:p-5">
                <div className="flex items-start gap-3">
                  <Gift className="mt-1 h-5 w-5 shrink-0 text-mhgreen" />
                  <div>
                    <h2 className="text-lg font-black text-mhgreen">
                      Hediye kutusu bilgisi
                    </h2>

                    <p className="mt-1 text-sm leading-6 text-muted">
                      Hediye kutusu siparişle birlikte gönderilecek.
                    </p>

                    {giftPackage.title && (
                      <p className="mt-3 text-sm font-bold text-foreground">
                        Başlık: {giftPackage.title}
                      </p>
                    )}

                    {giftPackage.note && (
                      <p className="mt-1 text-sm font-bold text-foreground">
                        Not: {giftPackage.note}
                      </p>
                    )}
                  </div>
                </div>
              </section>
            )}

            <section className="rounded-[1.35rem] border border-border-soft bg-panel/72 p-4 shadow-[0_18px_50px_rgba(0,0,0,0.18)] md:p-5">
              <h2 className="text-xl font-black text-foreground">
                Sipariş notu
              </h2>

              <textarea
                value={form.orderNote}
                onChange={(event) => updateForm("orderNote", event.target.value)}
                className="input-premium mt-4 min-h-24 resize-none py-3 text-sm"
                placeholder="Siparişle ilgili notun varsa yazabilirsin..."
              />
            </section>
          </div>

          <aside className="space-y-4 lg:sticky lg:top-24 lg:self-start">
            <section className="rounded-[1.35rem] border border-border-soft bg-panel/72 p-4 shadow-[0_18px_50px_rgba(0,0,0,0.18)] md:p-5">
              <div className="flex items-center gap-2">
                <PackageCheck className="h-5 w-5 text-mhgreen" />
                <h2 className="text-lg font-black text-foreground">
                  Sipariş özeti
                </h2>
              </div>

              <div className="mt-4 space-y-3">
                {items.map((item) => (
                  <CheckoutLine key={`normal-${item.productId}-${item.variantId}`} item={item} />
                ))}

                {giftPackage.items.map((item) => (
                  <CheckoutLine
                    key={`gift-${item.productId}-${item.variantId}`}
                    item={item}
                    badge="Hediye kutusu"
                  />
                ))}
              </div>

              <div className="mt-4 space-y-3 border-t border-border-soft pt-4">
                <div className="flex items-center justify-between text-sm">
                  <span className="text-muted">Sepet</span>
                  <span className="font-black text-foreground">
                    {formatPrice(subtotal)}
                  </span>
                </div>

                <div className="flex items-center justify-between text-sm">
                  <span className="text-muted">Hediye kutusu</span>
                  <span className="font-black text-foreground">
                    {formatPrice(giftSubtotal)}
                  </span>
                </div>

                <div className="flex items-center justify-between border-t border-border-soft pt-3">
                  <span className="text-sm font-black text-foreground">
                    Toplam
                  </span>
                  <span className="text-2xl font-black text-mhgreen">
                    {formatPrice(total)}
                  </span>
                </div>
              </div>

              {total < MIN_CART_TOTAL && (
                <div className="mt-4 rounded-2xl border border-warning/25 bg-warning/10 p-3 text-xs font-bold leading-5 text-warning">
                  Minimum sepet tutarı için {formatPrice(missingAmount)} daha
                  eklemelisin.
                </div>
              )}

              <button
                type="button"
                disabled={!canSubmit || isSubmitting}
                onClick={handleSubmit}
                className="mt-4 inline-flex min-h-11 w-full items-center justify-center gap-2 rounded-2xl bg-mhgreen px-4 text-sm font-black text-white shadow-[0_14px_30px_rgba(34,197,94,0.22)] transition hover:-translate-y-0.5 hover:bg-mhgreen-dark active:scale-[0.98] disabled:cursor-not-allowed disabled:opacity-45"
              >
                {isSubmitting ? (
                  <>
                    <Loader2 className="h-4 w-4 animate-spin" />
                    Sipariş oluşturuluyor
                  </>
                ) : (
                  "Siparişi Oluştur"
                )}
              </button>
            </section>

            <section className="grid gap-3">
              <div className="rounded-2xl border border-border-soft bg-panel/65 p-4">
                <ShieldCheck className="h-5 w-5 text-mhgreen" />
                <p className="mt-2 text-sm font-black text-foreground">
                  Güvenli akış
                </p>
                <p className="mt-1 text-xs leading-5 text-muted">
                  Stok ve sipariş bilgileri backend tarafında tekrar doğrulanır.
                </p>
              </div>

              <div className="rounded-2xl border border-border-soft bg-panel/65 p-4">
                <Truck className="h-5 w-5 text-mhgreen" />
                <p className="mt-2 text-sm font-black text-foreground">
                  Kargo bilgisi
                </p>
                <p className="mt-1 text-xs leading-5 text-muted">
                  Kargo takip entegrasyonunu sonraki adımda bağlayacağız.
                </p>
              </div>
            </section>
          </aside>
        </div>
      </section>
    </main>
  );
}